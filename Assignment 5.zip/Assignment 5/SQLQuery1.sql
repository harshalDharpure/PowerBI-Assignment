RESTORE FILELISTONLY  
FROM DISK = 'C:\mysqldata\AdventureWorksLT2022.bak';


RESTORE DATABASE AdventureWorksLT
FROM DISK = 'C:\mysqldata\AdventureWorksLT2022.bak'
WITH MOVE 'AdventureWorksLT2022_Data' TO 'C:\mysqldata\AdventureWorksLT.mdf',
MOVE 'AdventureWorksLT2022_Log' TO 'C:\mysqldata\AdventureWorksLT.ldf',
REPLACE;


SELECT servicename, service_account 
FROM sys.dm_server_services;

SELECT @@SERVERNAME AS ServerName;
